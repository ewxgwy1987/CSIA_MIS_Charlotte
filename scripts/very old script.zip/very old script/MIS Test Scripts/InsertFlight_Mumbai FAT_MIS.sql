/***************************************************************************************
 Description:	SQL Script to insert test Flight into table [FLIGHT_PLAN_SORTING]
 Created By:	HSC
 Date:			17 MAR 2010
***************************************************************************************/

USE [BHSDB]
GO

GO
DELETE FROM FLIGHT_PLAN_ERROR
DELETE FROM [FLIGHT_PLAN_SORTING] 
DELETE FROM [FLIGHT_PLANS] 
DELETE FROM FLIGHT_PLAN_ALLOC 
GO

BEGIN
	DECLARE	@FlightNumber int,@FLIGHTCOUNT int;
	DECLARE @FINAL_DEST VARCHAR(3), @DEST1 VARCHAR(3);
	
	DECLARE	@Hur int;
	DECLARE	@Hur_STR char(2);
	DECLARE	@Min int;
	DECLARE	@Min_STR char(2);

    SET @Hur = DATEPART(hh,GETDATE());
    SET @Min = 0;

	SET DATEFIRST 1;		
	SET @FLIGHTCOUNT=1
	WHILE @FLIGHTCOUNT < 9		
	BEGIN	
		IF @FLIGHTCOUNT = 1	
		BEGIN
			SET @FlightNumber = 145
			SET @FINAL_DEST = 'DEN'
			SET @DEST1 = NULL
		END
		ELSE IF @FLIGHTCOUNT = 2
		BEGIN
			SET @FlightNumber = 322
			SET @FINAL_DEST = 'FRN'
			SET @DEST1 = 'WAS'
		END
		ELSE IF @FLIGHTCOUNT = 3
		BEGIN
			SET @FlightNumber = 543
			SET @FINAL_DEST = 'HTN'
			SET @DEST1 =  NULL
		END
		ELSE IF @FLIGHTCOUNT = 4
		BEGIN
			SET @FlightNumber = 641
			SET @FINAL_DEST = 'TRC'
			SET @DEST1 = 'MAA'
		END
		ELSE IF @FLIGHTCOUNT = 5
		BEGIN
			SET @FlightNumber = 790
			SET @FINAL_DEST = 'KKP'
			SET @DEST1 =  NULL
		END
		ELSE IF @FLIGHTCOUNT = 6
		BEGIN
			SET @FlightNumber = 368
			SET @FINAL_DEST = 'DXB'
			SET @DEST1 =  NULL
		END
		ELSE IF @FLIGHTCOUNT = 7
		BEGIN
			SET @FlightNumber = 122
			SET @FINAL_DEST = 'LA'
			SET @DEST1 =  NULL
		END
		ELSE IF @FLIGHTCOUNT = 8
		BEGIN
			SET @FlightNumber = 599
			SET @FINAL_DEST = 'SIN'
			SET @DEST1 =  NULL
		END
			
		SET @Min_STR = CASE 
			 WHEN @Min=0 THEN '00'
			 WHEN @Min=10 THEN '10'
			 WHEN @Min=20 THEN '20'
			 WHEN @Min=30 THEN '30'
			 WHEN @Min=40 THEN '40'
			 WHEN @Min=50 THEN '50'
			 WHEN @Min=60 THEN '00'
		END
		
		IF @Min=60
		BEGIN
			SET @Hur = @Hur + 1
			SET @Min = 0
		END
		
		SET @Hur_STR = CASE 
			 WHEN @Hur<10 THEN '0' + CAST(@Hur AS varchar(1))
			 WHEN @Hur>=0 AND @Hur<24 THEN CAST(@Hur AS varchar(2))
			 WHEN @Hur=24 THEN '00'
		END

		IF @Hur=24
		BEGIN
			SET @Hur = 0
		END
		
		SET @Min = @Min + 20; -- Every 20 minutes interval create one flight
		
		-- Insert into FLIGHT_PLANS table as the ID in FLIGHT_PLAN_SORTING is a FK to the ID here.
		DECLARE @ID BIGINT
		INSERT INTO [BHSDB].[dbo].[FLIGHT_PLANS]
				   ([TIME_STAMP], [RAW_DATA], [ERROR_INDICATOR])
			 VALUES
				   (GETDATE(),'testing data', '0');
				   
		DECLARE @TIME_STAMP DATETIME = (SELECT MAX(TIME_STAMP) FROM FLIGHT_PLANS)
		SELECT @ID = ID FROM FLIGHT_PLANS WHERE TIME_STAMP = @TIME_STAMP;		

		-- Insert Today's flight
		Declare @TempSDO varchar(8) = CONVERT(varchar(8), GETDATE(), 112)
		declare @TempFlightNo varchar(5) = CAST(@FlightNumber AS varchar(3))
		declare @TempSTO varchar(14) = @TempSDO + @Hur_STR + @Min_STR + '00'
		
		INSERT INTO [BHSDB].[dbo].[FLIGHT_PLAN_SORTING] (
				[DATA_ID], [AIRLINE],[FLIGHT_NUMBER],[SDO],[STO],[EDO],[ETO],[ADO],[ATO],[IDO],[ITO],
				[AIRCRAFT_TYPE],[AIRCRAFT_VERSION],[MASTER_AIRLINE],[MASTER_FLIGHT_NUMBER],[HIGH_RISK],
				[CANCELLED],[TERMINAL],[GATE],[BOOKED_PAX],[NATURE],[HANDLER],[FINAL_DEST],[DEST1],
				[DEST2],[DEST3],[DEST4],[DEST5],[SORTING_DEST1],[SORTING_DEST2],[CHECKIN_AREA],
				[HBS_LEVEL_REQUIRED],[WEEKDAY],[HOUR],[TIME_STAMP],[CREATED_BY],[FI_EXCEPTION],[FLIGHT_TYPE])
			 VALUES (
				@ID,'IC',@TempFlightNo,CONVERT(nvarchar(30), GETDATE(), 111),
				   @Hur_STR + @Min_STR,CONVERT(nvarchar(30), GETDATE(), 111),
				   @Hur_STR + @Min_STR,null,null,null,null,null,null,null,null,null,'N','T3',null,
				   null,null,null,@FINAL_DEST,@DEST1,null,null,null,null,null,null,null,null,DATEPART(dw,DATEADD(hour,2,GETDATE())),
				   null,GETDATE(),'FIS',null,'0');		

		
	    SET @FLIGHTCOUNT = @FLIGHTCOUNT + 1;
	END
END
GO
/*
SELECT * FROM [BHSDB_MUMBAI].[dbo].[FLIGHT_PLANS]
SELECT * FROM [BHSDB_MUMBAI].[dbo].[FLIGHT_PLAN_SORTING]  
GO
*/

