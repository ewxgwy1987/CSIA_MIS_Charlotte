/***************************************************************************************
 Description:	SQL Script to insert test Flight into table [FLIGHT_PLAN_SORTING]
 Created By:	HSC
 Date:			17 MAR 2010
***************************************************************************************/

USE [BHSDB]
GO

GO
/*
DELETE FROM FLIGHT_PLAN_ERROR
DELETE FROM [FLIGHT_PLAN_SORTING] 
DELETE FROM [FLIGHT_PLANS] 
DELETE FROM FLIGHT_PLAN_ALLOC 
*/
GO

BEGIN
	DECLARE	@FlightNumber int,@FLIGHTCOUNT int;
	
	SET @FLIGHTCOUNT=1
	WHILE @FLIGHTCOUNT <= 1		
	BEGIN				
	
		-- Insert Flight Plan Allocation
		Declare @TempSDO varchar(8) = CONVERT(varchar(8), GETDATE(), 112)
		declare @TempFlightNo varchar(5) = CAST(@FlightNumber AS varchar(3))
		--declare @TempSTO varchar(14) = @TempSDO + @Hur_STR + @Min_STR + '00'
		
		INSERT INTO [BHSDB].[dbo].[FLIGHT_PLAN_ALLOC] 
			([AIRLINE],[FLIGHT_NUMBER],[SDO],[STO],[RESOURCE],[WEEKDAY],[EDO],[ETO],[ADO],[ATO],[IDO],[ITO]
			,[TRAVEL_CLASS],[FLIGHT_DESTINATION],[BAG_TYPE],[TRANSFER],[COMMENT_ID],[HIGH_RISK],[HBS_LEVEL_REQUIRED]
           ,[EARLY_OPEN_OFFSET],[EARLY_OPEN_ENABLED],[ALLOC_OPEN_OFFSET],[ALLOC_OPEN_RELATED],[ALLOC_CLOSE_OFFSET]
           ,[ALLOC_CLOSE_RELATED],[RUSH_DURATION],[SCHEME_TYPE],[CREATED_BY],[TIME_STAMP],[HOUR],[IS_MANUAL_CLOSE]
           ,[IS_CLOSED],[IS_MISS_TEMPLATE_FLIGHT])
     VALUES
           ('IC','122' ,@TempSDO,RIGHT('0' + CONVERT(VARCHAR(2),DATEPART(HOUR,GETDATE()) + 2), 2) + RIGHT('0' + CONVERT(VARCHAR(2),DATEPART(MINUTE,GETDATE())), 2),'MUC07','3',NULL,NULL,NULL,NULL,NULL,NULL
           ,'*','*','*','*',NULL,NULL,NULL,NULL,NULL,'-0200','STD','-0030','STD','0020',NULL,'BHS',GETDATE(),NULL,0,0,0)

		
	    SET @FLIGHTCOUNT = @FLIGHTCOUNT + 1;
	END
END
GO
/*
SELECT * FROM [BHSDB_MUMBAI].[dbo].[FLIGHT_PLANS]
SELECT * FROM [BHSDB_MUMBAI].[dbo].[FLIGHT_PLAN_SORTING]  
GO
*/

