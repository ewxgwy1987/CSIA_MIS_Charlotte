
/***************************************************************************************
 Description:	SQL Script to insert test BSM into table [BAGS]
 Created By:	XJ
 Date:			12 Jun 2008
***************************************************************************************/

USE [BHSDB]
GO

/* 
DELETE FROM BAG_ERROR_BSM
DELETE FROM BAG_INFO
DELETE FROM [BAG_SORTING]
DELETE FROM [dbo].[BAGS]
*/

DECLARE @i int;
DECLARE @GID BIGINT;
SET @GID = 1;
SET @i = 116;
WHILE @i = 116 -- Number of test bags will be inserted into table [BAGS] and [BAG_SORTING]
BEGIN
	DECLARE @No [varchar] (6);
	
	-- Up to 999 test bags can be inserted
	SET @No = CASE 
         WHEN @i<10 THEN '00000' + CAST(@i AS varchar(6))
         WHEN @i>=10 AND @i<100 THEN '0000' + CAST(@i AS varchar(6))
         WHEN @i>=100 AND @i<1000 THEN '000' + CAST(@i AS varchar(6))
         WHEN @i>=1000 AND @i<10000 THEN '00' + CAST(@i AS varchar(6))
         WHEN @i>=10000 AND @i<100000 THEN '0' + CAST(@i AS varchar(6))
         WHEN @i>=100000 AND @i<1000000 THEN CAST(@i AS varchar(6))
	END;
	
	-- insert into BAGS
	DECLARE @ID BIGINT
	INSERT INTO [BHSDB].[dbo].[BAGS]
			   ([TIME_STAMP], [RAW_DATA], [ERROR_INDICATOR])
		 VALUES
			   (GETDATE(),'BSM test DATA', '0');
			   
	DECLARE @TIME_STAMP DATETIME = (SELECT MAX(TIME_STAMP) FROM BAGS)
	SELECT @ID = ID FROM BAGS WHERE TIME_STAMP = @TIME_STAMP;			
	
	-- insert up to 999 test bags for flight SQ123
	IF @No IS NOT NULL
		INSERT INTO [BHSDB].[dbo].[BAG_SORTING] (
				   [DATA_ID],[TIME_STAMP],[LICENSE_PLATE],[AIRLINE],[FLIGHT_NUMBER],[SDO], 
				   [NO_PASSENGER_SAME_SURNAME], [SURNAME], [GIVEN_NAME], [OTHERS_NAME],
				   [TRAVEL_CLASS],[SOURCE],[HIGH_RISK],[HBS_LEVEL_REQUIRED],[CREATED_BY],[INBOUND_AIRLINE],
				   [INBOUND_FLIGHT_NUMBER],[TAG_PRINTER_ID],[CHECK_IN_COUNTER],[BAG_EXCEPTION])
			 VALUES
				   (@ID,GETDATE(),'0058' + @No,'IC','122',CONVERT(nvarchar(30), GETDATE(), 111),
				   0, 'AAA', 'BBB', '' ,'*','L',NULL,NULL,'BHS',NULL,NULL,NULL,NULL,NULL);
				   
	     INSERT INTO [BHSDB].[dbo].[BAG_INFO] (
                   [TIME_STAMP],[INDEX_NO],[PLC_INDEX_NO],[GID],[LICENSE_PLATE],[LICENSE_PLATE1]
                   ,[LICENSE_PLATE2],[LICENSE_PLATE3],[MIN_SECURITY_LEVEL],[CURRENT_HBS_LEVEL]
                   ,[HBS1_RESULT],[HBS2_RESULT],[HBS3_RESULT],[HBS4_RESULT],[HBS5_RESULT],[CUSTOMS_RESULT]
                   ,[SORT_REASON],[DEST1],[DEST2],[DEST3],[RECYLE_COUNT],[LAST_LOCATION],[ENCODED_TYPE]
                   ,[OOG],[EBS],[DISCHARGED],[DISAPPEARED],[SORTED],[CREATED_BY],[IS_MANUAL_REDIRECT],
                   [IS_ATR_NO_READ],[APP_CODE],[PROCEEDED_LOCATION])
             VALUES
                   (GETDATE(),'0001',NULL,'0038' + @No,'0058' + @No,'0058' + @No,NULL,NULL,'1','3','A','A','A',NULL,NULL,
                   'A','01','36',NULL,NULL,'0','STM03-131',NULL,0,0,1,0,1,'SACTTS01',0,0,'SACTTS01','36')
                   
	SET @i = @i + 1;
END
GO

SELECT * FROM [BAG_INFO]  
SELECT * FROM [BAG_SORTING]