-- ##########################################################################
-- Release#:    R1.0
-- Release On:  20 Aug 2009
-- Filename:    4.3.RPT_InsertINIData.sql
-- Description: SQL Scripts of Inserting initial data into reporting related tables.
--    Tables in which the initial data need to be inserted:
--	  1.[MIS_DATE_BASIC] 	
--
-- Histories:
--				R1.0 - Released on 20 Aug 2009.
-- ##########################################################################


USE [BHSDB]
GO


PRINT 'INFO: STEP 4.3 - Insert initial data into reporting related tables.'
PRINT 'INFO: .'
PRINT 'INFO: .'
PRINT 'INFO: .'
GO

PRINT 'INFO: Begining of Deleting Existing Initial Data...'
GO


PRINT 'INFO: Delete existing records from table [MIS_DATE_BASIC].'
DELETE FROM [dbo].[MIS_DATE_BASIC]

PRINT 'INFO: End of Deleting Existing Initial Data.'
GO
PRINT 'INFO: .'
PRINT 'INFO: .'
PRINT 'INFO: .'
GO
PRINT 'INFO: Begining of Insert New Initial Data...'
GO

/****** Object:  Table [dbo].[MIS_DATE_BASIC]    Script Date: 05/20/2011 09:56:52 ******/
PRINT 'INFO: Inserting initial records into table [MIS_DATE_BASIC]...'
INSERT [dbo].[MIS_DATE_BASIC] ([DATE_BASIC_VALUE], [DATE_BASIC_LABEL], [IS_DEFAULT]) VALUES (N'15MINUTES', N'15 MINUTES', 0)
INSERT [dbo].[MIS_DATE_BASIC] ([DATE_BASIC_VALUE], [DATE_BASIC_LABEL], [IS_DEFAULT]) VALUES (N'1DAY', N'1 DAY', 1)
INSERT [dbo].[MIS_DATE_BASIC] ([DATE_BASIC_VALUE], [DATE_BASIC_LABEL], [IS_DEFAULT]) VALUES (N'1HOUR', N'1 HOUR', 0)
INSERT [dbo].[MIS_DATE_BASIC] ([DATE_BASIC_VALUE], [DATE_BASIC_LABEL], [IS_DEFAULT]) VALUES (N'1MONTH', N'1 MONTH', 0)
INSERT [dbo].[MIS_DATE_BASIC] ([DATE_BASIC_VALUE], [DATE_BASIC_LABEL], [IS_DEFAULT]) VALUES (N'1WEEK', N'1 WEEK', 0)
INSERT [dbo].[MIS_DATE_BASIC] ([DATE_BASIC_VALUE], [DATE_BASIC_LABEL], [IS_DEFAULT]) VALUES (N'1YEAR', N'1 YEAR', 0)

GO

PRINT 'INFO: End of Insert New Initial Data.'
GO
PRINT 'INFO: .'
PRINT 'INFO: .'
PRINT 'INFO: .'
GO
PRINT 'INFO: End of STEP 4.3'
