-- ##########################################################################
-- Release#:    R1.0
-- Release On:  15 Mar 2010
-- Filename:    4.1.RPT_CreateTable.sql
-- Description: SQL Scripts of creating PALS reporting related tables in the 
--              Solution Database [BHSDB] (table, view, trigger, foreign keys, etc.)
--
--    Tables to be created by this script:
--    1.[MIS_DATE_BASIC]
--
--
-- Histories:
--				R1.0 - Released on 15 Mar 2010.
-- ##########################################################################


USE [BHSDB]
GO

PRINT 'INFO: STEP 4.1 - Creat reporting related tables.'
PRINT 'INFO: .'
PRINT 'INFO: .'
PRINT 'INFO: .'
GO
PRINT 'INFO: Begining of Drop Existing Tables...'
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MIS_DATE_BASIC]') AND type in (N'U'))
	DROP TABLE [dbo].[MIS_DATE_BASIC]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DESTINATION_GROUPING]') AND type in (N'U'))
	DROP TABLE [dbo].[DESTINATION_GROUPING]
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUBSYSTEM_GROUPING]') AND type in (N'U'))
	DROP TABLE [dbo].[SUBSYSTEM_GROUPING]



PRINT 'INFO: End of Drop Existing Tables.'
GO
PRINT 'INFO: .'
PRINT 'INFO: .'
PRINT 'INFO: .'
GO
PRINT 'INFO: Begining of Creating New Tables...'
GO

-- ****** Object:  Table [dbo].[MIS_DATE_BASIC]    Script Date: 10/08/2007 13:18:34 ******
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MIS_DATE_BASIC]') AND type in (N'U'))
BEGIN
	PRINT 'INFO: Deleting existing table [dbo].[MIS_DATE_BASIC]...'
	DROP TABLE [dbo].[MIS_DATE_BASIC]
END
GO
PRINT 'INFO: Creating table [dbo].[MIS_DATE_BASIC]...'
CREATE TABLE [dbo].[MIS_DATE_BASIC](
	[DATE_BASIC_VALUE] [varchar](20) NOT NULL,
	[DATE_BASIC_LABEL] [varchar](20) NULL,
	[IS_DEFAULT] [bit] NULL,
 CONSTRAINT [PK_MIS_DATE_BASIC] PRIMARY KEY CLUSTERED 
(
	[DATE_BASIC_VALUE] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

-- ****** Object:  Table [dbo].[DESTINATION_GROUPING]    Script Date: 10/08/2007 13:18:35 ******
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DESTINATION_GROUPING]') AND type in (N'U'))
BEGIN
	PRINT 'INFO: Deleting existing table [DESTINATION_GROUPING]...'
	DROP TABLE [dbo].[DESTINATION_GROUPING]
END
GO
PRINT 'INFO: Creating table [DESTINATION_GROUPING]...'
CREATE TABLE [dbo].[DESTINATION_GROUPING](
	[GROUP_NAME] [varchar](10) NOT NULL,
	[LOCATION] [varchar](20) NOT NULL,
	[SUBSYSTEM] [varchar](10) NOT NULL,
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO


-- ****** Object:  Table [dbo].[SUBSYSTEM_GROUPING]    Script Date: 11/01/2007 11:29:45 ******
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUBSYSTEM_GROUPING]') AND type in (N'U'))
BEGIN
	PRINT 'INFO: Deleting existing table [SUBSYSTEM_GROUPING]...'
	DROP TABLE [dbo].[SUBSYSTEM_GROUPING]
END
GO
PRINT 'INFO: Creating table [SUBSYSTEM_GROUPING]...'
CREATE TABLE [dbo].[SUBSYSTEM_GROUPING](
	[GROUP_NAME] [varchar](10) NOT NULL,
	[LOCATION] [varchar](20) NOT NULL,
	[SUBSYSTEM] [varchar](10) NOT NULL,
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF

GO
PRINT 'INFO: .'
PRINT 'INFO: .'
PRINT 'INFO: .'
GO
PRINT 'INFO: Begining of Creating New Foreign Keys...'
GO


-- ****** Object:  ForeignKey [FK_DESTINATION_GROUPING_NAME]    Script Date: 10/08/2007 13:18:35 ******
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DESTINATION_GROUPING_NAME]') 
		AND parent_object_id = OBJECT_ID(N'[dbo].[DESTINATION_GROUPING]'))
BEGIN
	PRINT 'INFO: Deleting existing ForeignKey [FK_DESTINATION_GROUPING_NAME]...'
	ALTER TABLE [dbo].[DESTINATION_GROUPING] DROP CONSTRAINT [FK_DESTINATION_GROUPING_NAME]
END
PRINT 'INFO: Creating ForeignKey [FK_DESTINATION_GROUPING_NAME]...'
ALTER TABLE [dbo].[DESTINATION_GROUPING]  WITH CHECK ADD  CONSTRAINT [FK_DESTINATION_GROUPING_NAME] FOREIGN KEY([GROUP_NAME])
REFERENCES [dbo].[DESTINATIONS] ([DESTINATION])
GO
ALTER TABLE [dbo].[DESTINATION_GROUPING] CHECK CONSTRAINT [FK_DESTINATION_GROUPING_NAME]
GO


-- ****** Object:  ForeignKey [FK_DESTINATION_GROUPING_LOCATION]    Script Date: 10/08/2007 13:18:35 ******
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_DESTINATION_GROUPING_LOCATION]') 
		AND parent_object_id = OBJECT_ID(N'[dbo].[DESTINATION_GROUPING]'))
BEGIN
	PRINT 'INFO: Deleting existing ForeignKey [FK_DESTINATION_GROUPING_LOCATION]...'
	ALTER TABLE [dbo].[DESTINATION_GROUPING] DROP CONSTRAINT [FK_DESTINATION_GROUPING_LOCATION]
END
PRINT 'INFO: Creating ForeignKey [FK_DESTINATION_GROUPING_LOCATION]...'
ALTER TABLE [dbo].[DESTINATION_GROUPING]  WITH CHECK ADD  CONSTRAINT [FK_DESTINATION_GROUPING_LOCATION] FOREIGN KEY([LOCATION], [SUBSYSTEM])
REFERENCES [dbo].[LOCATIONS] ([LOCATION], [SUBSYSTEM])
GO
ALTER TABLE [dbo].[DESTINATION_GROUPING] CHECK CONSTRAINT [FK_DESTINATION_GROUPING_LOCATION]
GO

PRINT 'INFO: End of Creating New Foreign Keys.'
GO

GO
PRINT 'INFO: .'
PRINT 'INFO: .'
PRINT 'INFO: .'
GO
PRINT 'INFO: Begining of Creating New Triggers...'
GO

PRINT 'INFO: End of Creating New Triggers.'
GO
PRINT 'INFO: .'
PRINT 'INFO: .'
PRINT 'INFO: .'
GO

PRINT 'INFO: End of Creating New Triggers.'
GO
PRINT 'INFO: .'
PRINT 'INFO: .'
PRINT 'INFO: .'
GO

PRINT 'INFO: End of STEP 4.1'
GO



